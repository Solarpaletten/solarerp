// scripts/backfill_task27.ts
// ═══════════════════════════════════════════════════
// Task 27: One-off backfill — populate debitAccountId /
// creditAccountId on SaleDocument & PurchaseDocument
// from existing SYSTEM journal entries.
// ═══════════════════════════════════════════════════
//
// P1-2: Deterministic backfill
//   - Only SYSTEM source entries
//   - Only SALE/PURCHASE documentType
//   - Exactly 1 debit line + 1 credit line → extract accountIds
//   - If ambiguous (0 or 2+ debit/credit lines) → abort with documentId
//
// Run once after migration:
//   npx ts-node scripts/backfill_task27.ts

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Task 27: Backfill account mapping from journal entries...\n');

  const errors: string[] = [];
  let salesUpdated = 0;
  let purchasesUpdated = 0;

  // ─── Backfill Sales ────────────────────────────
  const saleDocs = await prisma.saleDocument.findMany({
    where: {
      debitAccountId: null,
    },
    select: { id: true, series: true, number: true, companyId: true },
  });

  console.log(`Found ${saleDocs.length} sale documents without account mapping.`);

  for (const sale of saleDocs) {
    const entry = await prisma.journalEntry.findFirst({
      where: {
        documentId: sale.id,
        documentType: 'SALE',
        source: 'SYSTEM',
      },
      include: { lines: true },
    });

    if (!entry) {
      // No journal entry → skip (document created before journal integration)
      continue;
    }

    const debitLines = entry.lines.filter((l) => Number(l.debit) > 0);
    const creditLines = entry.lines.filter((l) => Number(l.credit) > 0);

    if (debitLines.length !== 1 || creditLines.length !== 1) {
      errors.push(
        `AMBIGUOUS: SaleDocument ${sale.id} (${sale.series}-${sale.number}) has ${debitLines.length} debit + ${creditLines.length} credit lines in journal entry ${entry.id}`
      );
      continue;
    }

    await prisma.saleDocument.update({
      where: { id: sale.id },
      data: {
        debitAccountId: debitLines[0].accountId,
        creditAccountId: creditLines[0].accountId,
      },
    });
    salesUpdated++;
  }

  // ─── Backfill Purchases ────────────────────────
  const purchaseDocs = await prisma.purchaseDocument.findMany({
    where: {
      debitAccountId: null,
    },
    select: { id: true, series: true, number: true, companyId: true },
  });

  console.log(`Found ${purchaseDocs.length} purchase documents without account mapping.`);

  for (const purchase of purchaseDocs) {
    const entry = await prisma.journalEntry.findFirst({
      where: {
        documentId: purchase.id,
        documentType: 'PURCHASE',
        source: 'SYSTEM',
      },
      include: { lines: true },
    });

    if (!entry) {
      continue;
    }

    const debitLines = entry.lines.filter((l) => Number(l.debit) > 0);
    const creditLines = entry.lines.filter((l) => Number(l.credit) > 0);

    if (debitLines.length !== 1 || creditLines.length !== 1) {
      errors.push(
        `AMBIGUOUS: PurchaseDocument ${purchase.id} (${purchase.series}-${purchase.number}) has ${debitLines.length} debit + ${creditLines.length} credit lines in journal entry ${entry.id}`
      );
      continue;
    }

    await prisma.purchaseDocument.update({
      where: { id: purchase.id },
      data: {
        debitAccountId: debitLines[0].accountId,
        creditAccountId: creditLines[0].accountId,
      },
    });
    purchasesUpdated++;
  }

  // ─── Report ────────────────────────────────────
  console.log(`\n=== Backfill Complete ===`);
  console.log(`Sales updated:    ${salesUpdated}`);
  console.log(`Purchases updated: ${purchasesUpdated}`);

  if (errors.length > 0) {
    console.error(`\n⚠️  ${errors.length} ERRORS (need manual resolution):`);
    for (const err of errors) {
      console.error(`  - ${err}`);
    }
    process.exit(1);
  }

  console.log('\n✅ All documents backfilled successfully.');
}

main()
  .catch((e) => {
    console.error('Backfill failed:', e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
