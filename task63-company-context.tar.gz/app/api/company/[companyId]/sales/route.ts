// app/api/company/[companyId]/sales/route.ts
// TASK 63 — migrated to requireCompanyContext
// Task 43: clientId FK + snapshot fields

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import {
  requireCompanyContext,
  companyContextErrorResponse,
} from '@/lib/auth/requireCompanyContext';
import { createJournalEntry } from '@/lib/accounting/journalService';
import { assertPeriodOpen } from '@/lib/accounting/periodLock';
import { createStockMovement } from '@/lib/accounting/stockService';
import { allocateFifoLots } from '@/lib/accounting/fifoService';
import { resolveFifoSaleAccounts, VatMode } from '@/lib/accounting/accountMapping';
import Decimal from 'decimal.js';

type RouteParams = {
  params: Promise<{ companyId: string }>;
};


// GET /api/company/[companyId]/sales
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { companyId, tenantId } = await requireCompanyContext(request);


    const sales = await prisma.saleDocument.findMany({
      where: { companyId, company: { tenantId } },
      include: { items: true },
      orderBy: { saleDate: 'desc' },
    });

    return NextResponse.json({ data: sales, count: sales.length });
  } catch (error) {
    const errRes = companyContextErrorResponse(error); if (errRes) return errRes;
    console.error('List sales error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/company/[companyId]/sales
export async function POST(request: NextRequest, { params }: RouteParams) {
  try {
    const { companyId, tenantId } = await requireCompanyContext(request);


    const body = await request.json();

    const {
      saleDate, series, number: docNumber,
      clientName: rawClientName, warehouseName,
      operationType, currencyCode, items,
    } = body;

    // Task 43: Resolve client via FK or legacy string
    let resolvedClientId: string | null = null;
    let resolvedClientName: string = rawClientName || '';
    let resolvedClientCode: string | null = body.clientCode || null;

    if (body.clientId) {
      const client = await prisma.client.findFirst({
        where: { id: body.clientId, companyId, company: { tenantId } },
        select: { id: true, name: true, code: true, isActive: true },
      });

      if (!client) {
        return NextResponse.json({ error: 'Client not found in this company' }, { status: 404 });
      }
      if (!client.isActive) {
        return NextResponse.json({ error: 'Client is deactivated' }, { status: 400 });
      }

      // Snapshot: freeze current client data into document
      resolvedClientId = client.id;
      resolvedClientName = client.name;
      resolvedClientCode = client.code;
    }

    if (!saleDate || !series || !docNumber || !resolvedClientName || !warehouseName || !operationType || !currencyCode) {
      return NextResponse.json({ error: 'Missing required sale fields' }, { status: 400 });
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: 'Sale must have at least one item' }, { status: 400 });
    }

    const result = await prisma.$transaction(async (tx) => {
      await assertPeriodOpen(tx, { companyId, date: new Date(saleDate) });

      const vatMode: VatMode = body.vatMode || 'VAT_19';
      const accounts = await resolveFifoSaleAccounts(tx, companyId, vatMode);

      const sale = await tx.saleDocument.create({
        data: {
          companyId,
          saleDate: new Date(saleDate),
          payUntil: body.payUntil ? new Date(body.payUntil) : null,
          accountingDate: body.accountingDate ? new Date(body.accountingDate) : null,
          series, number: docNumber,
          clientName: resolvedClientName,
          clientCode: resolvedClientCode,
          clientId: resolvedClientId,       // Task 43: FK
          payerName: body.payerName || null,
          payerCode: body.payerCode || null,
          unloadAddress: body.unloadAddress || null,
          unloadCity: body.unloadCity || null,
          warehouseName, operationType, currencyCode,
          employeeName: body.employeeName || null,
          comments: body.comments || null,
          debitAccountId: accounts.arAccountId,
          creditAccountId: accounts.revenueAccountId,
          items: {
            create: items.map((item: {
              itemName: string; itemCode?: string; barcode?: string;
              quantity: number; priceWithoutVat: number; unitDiscount?: number;
              vatRate?: number; vatClassifier?: string;
              salesAccountCode?: string; expenseAccountCode?: string; costCenter?: string;
            }) => ({
              itemName: item.itemName,
              itemCode: item.itemCode || null,
              barcode: item.barcode || null,
              quantity: item.quantity,
              priceWithoutVat: item.priceWithoutVat,
              unitDiscount: item.unitDiscount || null,
              vatRate: item.vatRate || null,
              vatClassifier: item.vatClassifier || null,
              salesAccountCode: item.salesAccountCode || null,
              expenseAccountCode: item.expenseAccountCode || null,
              costCenter: item.costCenter || null,
            })),
          },
        },
        include: { items: true },
      });

      let totalCogs = new Decimal(0);
      for (const item of sale.items) {
        const itemCode = item.itemCode || item.itemName;
        const fifoResult = await allocateFifoLots(tx, {
          companyId, warehouseName: sale.warehouseName,
          itemCode, itemName: item.itemName,
          quantity: item.quantity, documentType: 'SALE',
          documentId: sale.id, saleItemId: item.id,
        });
        totalCogs = totalCogs.plus(fifoResult.totalCogs);
      }

      const totalRevenue = items.reduce(
        (sum: number, item: { quantity: number; priceWithoutVat: number }) =>
          sum + Number(item.quantity) * Number(item.priceWithoutVat), 0
      );

      if (totalRevenue <= 0) throw new Error('Total revenue must be positive');

      const journalLines = [
        { accountId: accounts.arAccountId, debit: totalRevenue, credit: 0 },
        { accountId: accounts.revenueAccountId, debit: 0, credit: totalRevenue },
        ...(totalCogs.gt(0) ? [
          { accountId: accounts.cogsAccountId, debit: Number(totalCogs.toFixed(2)), credit: 0 },
          { accountId: accounts.inventoryAccountId, debit: 0, credit: Number(totalCogs.toFixed(2)) },
        ] : []),
      ];

      const journalEntry = await createJournalEntry(tx, {
        companyId, date: new Date(saleDate),
        documentType: 'SALE', documentId: sale.id, lines: journalLines,
      });

      for (const item of sale.items) {
        await createStockMovement({
          tx, companyId, warehouseName: sale.warehouseName,
          itemName: item.itemName, itemCode: item.itemCode || item.itemName,
          quantity: Number(item.quantity), cost: Number(item.priceWithoutVat),
          direction: 'OUT', documentType: 'SALE', documentId: sale.id,
          documentDate: sale.saleDate, series: sale.series, number: docNumber,
        });
      }

      return { sale, journalEntry, totalCogs: Number(totalCogs.toFixed(2)) };
    });

    return NextResponse.json({
      data: result.sale,
      journal: { id: result.journalEntry.id, linesCount: result.journalEntry.lines.length },
      cogs: result.totalCogs,
    }, { status: 201 });
  } catch (error: unknown) {
    const errRes = companyContextErrorResponse(error); if (errRes) return errRes;

    if (error && typeof error === 'object' && 'code' in error && (error as { code: string }).code === 'P2002') {
      return NextResponse.json({ error: 'Sale with this series/number already exists' }, { status: 409 });
    }

    const message = error instanceof Error ? error.message : 'Internal server error';
    if (message.startsWith('INSUFFICIENT_STOCK') || message.startsWith('FIFO_ALLOCATION_INCOMPLETE')) {
      return NextResponse.json({ error: message }, { status: 409 });
    }
    if (message.startsWith('ACCOUNT_CODE_NOT_FOUND')) {
      return NextResponse.json({ error: message }, { status: 400 });
    }

    console.error('Create sale error:', message);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
