draft
→ posted
→ accounting
→ warehouse