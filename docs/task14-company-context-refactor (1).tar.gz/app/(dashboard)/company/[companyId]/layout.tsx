// app/(dashboard)/company/[companyId]/layout.tsx
// ═══════════════════════════════════════════════════
// Company Layout — Server Component
// Fetches company data ONCE via Prisma (server-side)
// Wraps children in CompanyProvider (client context)
// ═══════════════════════════════════════════════════
//
// Architecture:
//   layout.tsx (server) → Prisma query → CompanyProvider (client)
//     ├── CompanySidebar  → useCompany()  ← no fetch
//     ├── CompanyHeader   → useCompany()  ← no fetch
//     └── page.tsx        → useCompany()  ← no fetch
//
// Result: 1 DB query per navigation, not 4 HTTP requests.

import prisma from '@/lib/prisma';
import { notFound, redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { CompanyProvider } from './CompanyContext';
import CompanySidebar from './CompanySidebar';
import CompanyHeader from './CompanyHeader';

export default async function CompanyLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ companyId: string }>;
}) {
  const { companyId } = await params;

  // ─── AUTH CHECK ────────────────────────────────
  // Verify session cookie exists (middleware also checks,
  // but layout needs it for Prisma tenant scope)
  const cookieStore = await cookies();
  const sessionToken = cookieStore.get('solar_session')?.value;

  if (!sessionToken) {
    redirect('/login');
  }

  // ─── RESOLVE TENANT FROM SESSION ───────────────
  let tenantId: string | null = null;
  try {
    const session = await prisma.session.findUnique({
      where: { token: sessionToken },
      select: { tenantId: true, expiresAt: true },
    });

    if (!session || session.expiresAt < new Date()) {
      redirect('/login');
    }

    tenantId = session.tenantId;
  } catch {
    redirect('/login');
  }

  // ─── FETCH COMPANY (TENANT-SCOPED) ─────────────
  const company = await prisma.company.findFirst({
    where: {
      id: companyId,
      tenantId, // TENANT SCOPE — cannot access other tenant's company
    },
    select: {
      id: true,
      name: true,
      status: true,
    },
  });

  if (!company) {
    notFound();
  }

  // ─── RENDER WITH CONTEXT ───────────────────────
  // CompanyProvider is 'use client' — receives serializable data
  const companyData = {
    id: company.id,
    name: company.name,
    status: company.status,
  };

  return (
    <CompanyProvider value={companyData}>
      <div className="flex min-h-screen">
        {/* Sidebar */}
        <aside className="w-60 shrink-0">
          <CompanySidebar companyId={companyId} />
        </aside>

        {/* Main area */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <CompanyHeader />

          {/* Page content */}
          <main className="flex-1 bg-gray-50 overflow-auto">
            {children}
          </main>
        </div>
      </div>
    </CompanyProvider>
  );
}
