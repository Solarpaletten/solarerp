# TASK31_REPORT.md — Accounting Mapping Layer (SKR03 Abstraction)

## Scope

- ✅ `lib/accounting/accountMapping.ts` — single source of truth
- ✅ `ACCOUNT_MAP` — all SKR03 code references centralized
- ✅ `resolveSaleAccounts()` — code→ID resolver for sales
- ✅ `resolvePurchaseAccounts()` — code→ID resolver for purchases
- ✅ `resolveSimplePosting()` — generic debit/credit code→ID
- ✅ `getDefaultPostingCodes()` — returns default codes per doc type
- ✅ Batch resolver — single DB query for multiple codes
- ✅ No migration, no schema changes, no UI changes

## Files

| File | Type | Lines |
|------|------|-------|
| `lib/accounting/accountMapping.ts` | NEW | 223 |

## Architecture

### Current state (before Task 31)

```
Sales route → body.journal.debitAccountId (raw UUID from client)
            → body.journal.creditAccountId (raw UUID from client)
            → createJournalEntry(tx, { lines: [...] })
```

The client must know account UUIDs. No code-level abstraction.

### After Task 31

```
accountMapping.ts
  ├── ACCOUNT_MAP (const, typed)
  │     bank: "1020", cash: "1000", receivable: "1200", payable: "1600"
  │     sales.VAT_19.revenue: "8400", sales.VAT_19.vat: "1776"
  │     purchase.VAT_19.expense: "3400", purchase.VAT_19.vat: "1400"
  │     ...
  │
  ├── resolveSaleAccounts(tx, companyId, vatMode)
  │     → { debitAccountId, creditAccountId, vatAccountId? }
  │
  ├── resolvePurchaseAccounts(tx, companyId, vatMode)
  │     → { debitAccountId, creditAccountId, vatAccountId? }
  │
  ├── resolveSimplePosting(tx, companyId, debitCode, creditCode)
  │     → { debitAccountId, creditAccountId }
  │
  └── getDefaultPostingCodes(docType, vatMode)
        → { debitCode, creditCode, vatCode? }
```

### Why journalService/repostingService are NOT modified

These services work with **account IDs** (UUIDs), not codes. They are already code-agnostic:

- `journalService.createJournalEntry()` — takes `accountId` in lines
- `repostingService.repostRange()` — reads `debitAccountId/creditAccountId` from documents

The mapping layer sits **above** these services, at the route level, resolving codes→IDs before passing to the service layer. This preserves separation of concerns.

### Integration point (future / Air Engine)

Routes can now do:
```ts
// Instead of requiring client to send UUIDs:
const accounts = await resolveSaleAccounts(tx, companyId, 'VAT_19');

// Use resolved IDs:
await createJournalEntry(tx, {
  companyId,
  date: saleDate,
  documentType: 'SALE',
  documentId: sale.id,
  lines: [
    { accountId: accounts.debitAccountId, debit: grossAmount, credit: 0 },
    { accountId: accounts.creditAccountId, debit: 0, credit: netAmount },
    ...(accounts.vatAccountId ? [{
      accountId: accounts.vatAccountId, debit: 0, credit: vatAmount
    }] : []),
  ],
});
```

## ACCOUNT_MAP Reference

| Role | Code | SKR03 Name |
|------|------|-----------|
| bank | 1020 | Bank |
| cash | 1000 | Kasse |
| receivable | 1200 | Forderungen aus L+L |
| payable | 1600 | Verbindlichkeiten aus L+L |
| sales.VAT_19.revenue | 8400 | Erlöse 19% USt |
| sales.VAT_19.vat | 1776 | Umsatzsteuer 19% |
| sales.VAT_7.revenue | 8300 | Erlöse 7% USt |
| sales.VAT_7.vat | 1771 | Umsatzsteuer 7% |
| sales.EXPORT.revenue | 8125 | Steuerfreie ig. Lieferung |
| purchase.VAT_19.expense | 3400 | Wareneingang 16% Vorsteuer |
| purchase.VAT_19.vat | 1400 | Abziehbare Vorsteuer |
| purchase.VAT_7.expense | 3100 | Einkauf RHB 7% |
| purchase.VAT_7.vat | 1406 | Abziehbare Vorsteuer 7% |
| equity.capital | 0800 | Gezeichnetes Kapital |
| equity.retainedEarnings | 0840 | Gewinnvortrag |
| equity.annualResult | 0868 | Jahresüberschuss |
| opening | 9008 | Eröffnungsbilanz |
| closing | 9009 | Schlussbilanzkonto |

## Apply

```bash
tar -xzf task31-account-mapping.tar.gz -C .
# No migration needed — pure library file
```

## DoD Checklist

| # | Check | Status |
|---|-------|--------|
| 1 | ACCOUNT_MAP contains all SKR03 role assignments | ✅ |
| 2 | Typed resolvers: sale, purchase, simple | ✅ |
| 3 | Batch resolution (single DB query) | ✅ |
| 4 | Error on missing codes (import SKR03 first) | ✅ |
| 5 | No schema changes | ✅ |
| 6 | No UI changes | ✅ |
| 7 | journalService untouched (already code-agnostic) | ✅ |
| 8 | repostingService untouched (uses stored IDs) | ✅ |
| 9 | TypeScript strict types (as const, VatMode) | ✅ |
