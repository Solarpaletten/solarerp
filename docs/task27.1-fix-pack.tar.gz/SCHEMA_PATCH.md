# Task 27.1: Schema Patch — Prisma-first Migration

## P0-2: Migration via `prisma migrate`, NOT raw SQL files

### 1. Update `schema.prisma`:

Add enum before JournalEntry:
```prisma
enum JournalSource {
  SYSTEM
  MANUAL
}
```

Update JournalEntry model:
```prisma
model JournalEntry {
  id           String        @id @default(cuid())
  companyId    String
  date         DateTime
  documentType String
  documentId   String?
  source       JournalSource @default(SYSTEM)   // Task 27
  createdAt    DateTime      @default(now())

  lines   JournalLine[]
  company Company       @relation(fields: [companyId], references: [id], onDelete: Cascade)

  @@index([companyId])
  @@index([date])
  @@index([documentType])
  @@index([documentId])
  @@index([companyId, date])     // Task 27
  @@index([companyId, source])   // Task 27
  @@map("journal_entries")
}
```

Update SaleDocument — after `comments String?`:
```prisma
  debitAccountId  String?
  creditAccountId String?
```

Update PurchaseDocument — after `status String?`:
```prisma
  debitAccountId  String?
  creditAccountId String?
```

### 2. Generate migration:
```bash
npx prisma migrate dev --name task27_reposting
npx prisma generate
```

### 3. Run backfill (one-off):
```bash
npx ts-node scripts/backfill_task27.ts
```

### 4. Patch sales/purchases POST routes:

In sales POST, inside transaction after `const sale = await tx.saleDocument.create(...)`:
```ts
// Task 27: Persist account mapping for reposting
await tx.saleDocument.update({
  where: { id: sale.id },
  data: {
    debitAccountId: journal.debitAccountId,
    creditAccountId: journal.creditAccountId,
  },
});
```

Same in purchases POST after `const purchase = await tx.purchaseDocument.create(...)`.
