// app/api/account/companies/route.ts
// ═══════════════════════════════════════════════════════════════
// TASK 62 — Companies API with validation + duplicate prevention
//
// GET  — list via CompanyUser membership
// POST — create with validation (min 3 chars, no duplicates)
// ═══════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { requireTenant } from '@/lib/auth/requireTenant';

// ─── GET /api/account/companies ───────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const { userId, tenantId } = await requireTenant(request);

    const memberships = await (prisma as any).companyUser.findMany({
      where: { userId },
      select: {
        role: true,
        isOwner: true,
        company: {
          select: {
            id: true, name: true, country: true,
            legalType: true, currencyCode: true,
            vatPayer: true, status: true,
            onboardingCompletedAt: true,
            priority: true, createdAt: true,
            tenantId: true,
          },
        },
      },
      orderBy: [
        { company: { priority: 'desc' } },
        { company: { createdAt: 'asc' } },
      ],
    });

    const companies = memberships
      .filter((m: any) => m.company.tenantId === tenantId)
      .map((m: any) => ({
        id:                  m.company.id,
        name:                m.company.name,
        country:             m.company.country,
        legalType:           m.company.legalType,
        currencyCode:        m.company.currencyCode,
        vatPayer:            m.company.vatPayer,
        status:              m.company.status,
        onboardingCompleted: !!m.company.onboardingCompletedAt,
        priority:            m.company.priority,
        createdAt:           m.company.createdAt,
        role:                m.role,
        isOwner:             m.isOwner,
      }));

    return NextResponse.json({ data: companies });
  } catch (err) {
    if (err instanceof Response) {
      return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });
    }
    console.error('[GET /api/account/companies]', err);
    return NextResponse.json({ error: 'INTERNAL_ERROR' }, { status: 500 });
  }
}

// ─── POST /api/account/companies ──────────────────────────────
// Validates + creates company + grants OWNER access
export async function POST(request: NextRequest) {
  try {
    const { userId, tenantId } = await requireTenant(request);

    const body = await request.json();
    const { name, country, legalType, vatPayer, code } = body;

    // ── Validation ────────────────────────────────────────────
    const trimmedName = name?.trim() || '';

    if (!trimmedName) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Company name is required' },
        { status: 400 }
      );
    }

    if (trimmedName.length < 3) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Company name must be at least 3 characters' },
        { status: 400 }
      );
    }

    if (trimmedName.length > 100) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Company name must be 100 characters or less' },
        { status: 400 }
      );
    }

    // ── Duplicate check ───────────────────────────────────────
    const existing = await prisma.company.findFirst({
      where: {
        tenantId,
        name: { equals: trimmedName, mode: 'insensitive' },
      },
      select: { id: true },
    });

    if (existing) {
      return NextResponse.json(
        { error: 'DUPLICATE_ERROR', message: `Company "${trimmedName}" already exists` },
        { status: 409 }
      );
    }

    // ── Create ────────────────────────────────────────────────
    const maxPriority = await prisma.company.aggregate({
      where: { tenantId },
      _max: { priority: true },
    });

    const company = await prisma.company.create({
      data: {
        tenantId,
        name:         trimmedName,
        country:      country?.trim().toUpperCase() || 'DE',
        legalType:    legalType?.trim()             || 'GmbH',
        vatPayer:     vatPayer !== false,
        currencyCode: body.currencyCode             || 'EUR',
        code:         code?.trim()                  || null,
        status:       'ACTIVE',
        priority:     (maxPriority._max.priority ?? 0) + 1,
        createdByUserId: userId,
      },
    });

    // Grant OWNER access
    await (prisma as any).companyUser.upsert({
      where: { companyId_userId: { companyId: company.id, userId } },
      update: { role: 'OWNER', isOwner: true },
      create: { companyId: company.id, userId, role: 'OWNER', isOwner: true },
    });

    return NextResponse.json({ data: company }, { status: 201 });
  } catch (err) {
    if (err instanceof Response) {
      return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });
    }
    console.error('[POST /api/account/companies]', err);
    return NextResponse.json({ error: 'INTERNAL_ERROR' }, { status: 500 });
  }
}
