// lib/accounting/accountMapping.ts
// ═══════════════════════════════════════════════════
// Accounting Mapping Layer — SKR03 Abstraction
// ═══════════════════════════════════════════════════
//
// Task 31: Single source of truth for account code assignments.
//
// Purpose:
//   1. Define which SKR03 codes map to which accounting roles
//   2. Resolve codes → account IDs at runtime (per company)
//   3. Provide typed helpers for Sales, Purchases, Manual entries
//
// Rules:
//   - No hardcoded account codes outside this file
//   - All code references go through ACCOUNT_MAP
//   - Resolver validates accounts exist before returning IDs
//   - No schema changes, no migrations

import { PrismaClient } from '@prisma/client';

type TxClient = Omit<
  PrismaClient,
  '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'
>;

// ─── VAT Modes ───────────────────────────────────
export type VatMode = 'VAT_19' | 'VAT_7' | 'EXPORT';

// ─── SKR03 Account Map (code references only) ────
// Single source of truth. All account code usage
// in the system MUST reference this map.
export const ACCOUNT_MAP = {
  // Balance sheet — general
  bank: '1020',
  cash: '1000',
  receivable: '1200',
  payable: '1600',

  // Sales by VAT mode
  sales: {
    VAT_19: {
      revenue: '8400',
      vat: '1776',
    },
    VAT_7: {
      revenue: '8300',
      vat: '1771',
    },
    EXPORT: {
      revenue: '8125',
      // No VAT on exports
    },
  },

  // Purchases by VAT mode
  purchase: {
    VAT_19: {
      expense: '3400',
      vat: '1400',
    },
    VAT_7: {
      expense: '3100',
      vat: '1406',
    },
  },

  // Equity / year-end
  equity: {
    capital: '0800',
    retainedEarnings: '0840',
    lossCarryforward: '0860',
    annualResult: '0868',
  },

  // Opening / closing
  opening: '9008',
  closing: '9009',
} as const;

// ─── Types for resolved account IDs ──────────────
export type ResolvedSaleAccounts = {
  debitAccountId: string;   // receivable account ID
  creditAccountId: string;  // revenue account ID
  vatAccountId?: string;    // VAT account ID (undefined for EXPORT)
};

export type ResolvedPurchaseAccounts = {
  debitAccountId: string;   // expense account ID
  creditAccountId: string;  // payable account ID
  vatAccountId?: string;    // input VAT account ID
};

// ─── Resolver: code → account ID ─────────────────
// Fetches account by code+companyId, returns ID.
// Throws if not found (import SKR03 first).

async function resolveCode(
  tx: TxClient,
  companyId: string,
  code: string
): Promise<string> {
  const account = await tx.account.findFirst({
    where: { companyId, code },
    select: { id: true },
  });
  if (!account) {
    throw new Error(
      `ACCOUNT_CODE_NOT_FOUND: Code "${code}" not found for company ${companyId}. Import SKR03 first.`
    );
  }
  return account.id;
}

// ─── Batch resolver: multiple codes → IDs ────────
// Single query, returns Map<code, id>.
async function resolveCodes(
  tx: TxClient,
  companyId: string,
  codes: string[]
): Promise<Map<string, string>> {
  const uniqueCodes = [...new Set(codes)];
  const accounts = await tx.account.findMany({
    where: { companyId, code: { in: uniqueCodes } },
    select: { id: true, code: true },
  });

  const map = new Map<string, string>();
  for (const acc of accounts) {
    map.set(acc.code, acc.id);
  }

  // Validate all codes resolved
  const missing = uniqueCodes.filter((c) => !map.has(c));
  if (missing.length > 0) {
    throw new Error(
      `ACCOUNT_CODE_NOT_FOUND: Codes not found for company ${companyId}: ${missing.join(', ')}. Import SKR03 first.`
    );
  }

  return map;
}

// ─── Sale Account Resolver ───────────────────────
// Given a VAT mode, resolves the correct account IDs
// for a sale document posting.
//
// Sale 19%:
//   Debit:  1200 (Receivable)     → gross amount
//   Credit: 8400 (Revenue 19%)    → net amount
//   Credit: 1776 (Output VAT 19%) → VAT amount
//
// Sale Export:
//   Debit:  1200 (Receivable)     → full amount
//   Credit: 8125 (Export Revenue)  → full amount
export async function resolveSaleAccounts(
  tx: TxClient,
  companyId: string,
  vatMode: VatMode
): Promise<ResolvedSaleAccounts> {
  const salesConfig = ACCOUNT_MAP.sales[vatMode];
  const codes = [
    ACCOUNT_MAP.receivable,
    salesConfig.revenue,
  ];

  if ('vat' in salesConfig) {
    codes.push(salesConfig.vat);
  }

  const map = await resolveCodes(tx, companyId, codes);

  return {
    debitAccountId: map.get(ACCOUNT_MAP.receivable)!,
    creditAccountId: map.get(salesConfig.revenue)!,
    vatAccountId: 'vat' in salesConfig
      ? map.get(salesConfig.vat)
      : undefined,
  };
}

// ─── Purchase Account Resolver ───────────────────
// Given a VAT mode, resolves the correct account IDs
// for a purchase document posting.
//
// Purchase 19%:
//   Debit:  3400 (Expense)        → net amount
//   Debit:  1400 (Input VAT 19%)  → VAT amount
//   Credit: 1600 (Payable)        → gross amount
export async function resolvePurchaseAccounts(
  tx: TxClient,
  companyId: string,
  vatMode: 'VAT_19' | 'VAT_7'
): Promise<ResolvedPurchaseAccounts> {
  const purchaseConfig = ACCOUNT_MAP.purchase[vatMode];
  const codes = [
    purchaseConfig.expense,
    ACCOUNT_MAP.payable,
    purchaseConfig.vat,
  ];

  const map = await resolveCodes(tx, companyId, codes);

  return {
    debitAccountId: map.get(purchaseConfig.expense)!,
    creditAccountId: map.get(ACCOUNT_MAP.payable)!,
    vatAccountId: map.get(purchaseConfig.vat),
  };
}

// ─── Simple 2-line posting resolver ──────────────
// For current architecture where routes pass
// debitAccountId/creditAccountId directly.
// This resolves codes to IDs for simple debit/credit pairs.
export async function resolveSimplePosting(
  tx: TxClient,
  companyId: string,
  debitCode: string,
  creditCode: string
): Promise<{ debitAccountId: string; creditAccountId: string }> {
  const map = await resolveCodes(tx, companyId, [debitCode, creditCode]);
  return {
    debitAccountId: map.get(debitCode)!,
    creditAccountId: map.get(creditCode)!,
  };
}

// ─── Get default posting profile for document ────
// Returns the default debit/credit codes for a
// document type + VAT mode combination.
// Used by routes to auto-assign accounts when
// the client doesn't specify them explicitly.
export function getDefaultPostingCodes(
  docType: 'SALE' | 'PURCHASE',
  vatMode: VatMode = 'VAT_19'
): { debitCode: string; creditCode: string; vatCode?: string } {
  if (docType === 'SALE') {
    const config = ACCOUNT_MAP.sales[vatMode];
    return {
      debitCode: ACCOUNT_MAP.receivable,
      creditCode: config.revenue,
      vatCode: 'vat' in config ? config.vat : undefined,
    };
  } else {
    const config = ACCOUNT_MAP.purchase[vatMode as 'VAT_19' | 'VAT_7'];
    return {
      debitCode: config.expense,
      creditCode: ACCOUNT_MAP.payable,
      vatCode: config.vat,
    };
  }
}
