# Task 59 — Company Switcher — Install Guide

## Files in this archive

```
lib/auth/requireCompanyContext.ts          ← core middleware
lib/api/apiClient.ts                       ← client with AbortController
components/layouts/CompanySwitcher.tsx     ← UI switcher
app/api/account/companies/route.ts         ← GET companies list
app/api/company/[companyId]/clients/route.ts  ← reference route
```

## Deploy (one command)

```bash
cd /path/to/solar-erp
tar -xzf task59_clean.tar.gz
pnpm build
```

## Verify (3 tests)

```bash
# Get your session cookie first: login at localhost:3000

COOKIE="your_solar_session_cookie"
COMPANY="seed-company-solar-erp-demo"

# Test 1: No X-Company-Id → 400
curl http://localhost:3000/api/company/$COMPANY/clients \
  -H "Cookie: solar_session=$COOKIE"
# Expected: {"error":"COMPANY_CONTEXT_MISSING"}

# Test 2: Wrong company → 403
curl http://localhost:3000/api/company/wrong-id/clients \
  -H "Cookie: solar_session=$COOKIE" \
  -H "X-Company-Id: wrong-id"
# Expected: {"error":"COMPANY_ACCESS_DENIED"}

# Test 3: Valid → 200
curl http://localhost:3000/api/company/$COMPANY/clients \
  -H "Cookie: solar_session=$COOKIE" \
  -H "X-Company-Id: $COMPANY"
# Expected: {"data":[...],"total":N}
```

## Rules (HARD — no bypass)
- ❌ NO fallback company
- ❌ NO default company  
- ❌ NO backend state
- ✅ X-Company-Id header required on every /api/company/* request
- ✅ tenant isolation: company.tenantId === session.tenantId
