# TASK26_REPORT.md — Balance Sheet (Bilanz) Aggregator MVP

## Scope

- ✅ `GET /api/company/[companyId]/reports/balance-sheet?asOf=YYYY-MM-DD`
- ✅ Validates `asOf` (required, ISO date)
- ✅ Aggregates ALL JournalLine up to asOf (inclusive, end of day)
- ✅ Classifies by Account.type: ASSET, LIABILITY, EQUITY
- ✅ ASSET: `displayBalance = rawBalance` (debit - credit)
- ✅ LIABILITY/EQUITY: `displayBalance = -rawBalance` (positive display)
- ✅ INCOME/EXPENSE → synthetic "Current Period Result" line in equity
- ✅ `netProfit = totalIncome - totalExpenses` (P&L logic inline)
- ✅ Totals: assets, liabilities, equity, liabilitiesPlusEquity, diff
- ✅ Returns 200 always, `diff` for debug (not 409)
- ✅ Sorted by `code` ASC
- ✅ Tenant-safe (two-level isolation)
- ✅ No UI, no migration, no schema changes

## File

| File | Type | Lines |
|------|------|-------|
| `app/api/company/[companyId]/reports/balance-sheet/route.ts` | NEW | 213 |

## Apply

```bash
tar -xzf task26-balance-sheet.tar.gz -C .
# No migration — pure endpoint
```

## Verification (curl)

```bash
# 1. Balance Sheet на дату
curl 'http://localhost:3000/api/company/{companyId}/reports/balance-sheet?asOf=2026-02-26' \
  -H 'Cookie: session=...'

# Ожидаемый ответ:
# {
#   "asOf": "2026-02-26",
#   "assets": [
#     { "accountId": "...", "code": "1200", "name": "Accounts Receivable", "balance": 1000.00 }
#   ],
#   "liabilities": [
#     { "accountId": "...", "code": "3300", "name": "Accounts Payable", "balance": 400.00 }
#   ],
#   "equity": [
#     { "accountId": "...", "code": "3000", "name": "Share Capital", "balance": 0 },
#     { "accountId": "P&L", "code": "P&L", "name": "Current Period Result", "balance": 600.00 }
#   ],
#   "totals": {
#     "assets": 1000.00,
#     "liabilities": 400.00,
#     "equity": 600.00,
#     "liabilitiesPlusEquity": 1000.00,
#     "diff": 0
#   }
# }

# 2. Без параметра → 400
curl 'http://localhost:3000/api/company/{companyId}/reports/balance-sheet' \
  -H 'Cookie: session=...'
# → 400: "asOf" query parameter is required

# 3. Чужая компания → 404
curl 'http://localhost:3000/api/company/wrong-id/reports/balance-sheet?asOf=2026-02-26' \
  -H 'Cookie: session=...'
# → 404: Company not found

# 4. Пустая дата (нет проводок) → пустой баланс
curl 'http://localhost:3000/api/company/{companyId}/reports/balance-sheet?asOf=2020-01-01' \
  -H 'Cookie: session=...'
# → { "asOf": "2020-01-01", "assets": [], "liabilities": [], "equity": [], "totals": { ... diff: 0 } }
```

## DoD Checklist

| # | Check | Status |
|---|-------|--------|
| 1 | tenant-safe (чужая company → 404) | ✅ |
| 2 | equity содержит "Current Period Result" | ✅ |
| 3 | diff отображается, на seed abs(diff) <= 0.01 | ✅ |
| 4 | asOf обязателен, валидация | ✅ |
| 5 | ASSET: rawBalance, LIABILITY/EQUITY: -rawBalance | ✅ |
| 6 | Sorted by code ASC | ✅ |
| 7 | Returns 200 always | ✅ |

## Data Flow

```
GET /reports/balance-sheet?asOf=2026-02-26
  │
  ├─ requireTenant() → tenantId
  ├─ verifyCompanyOwnership()
  ├─ Validate asOf
  │
  ├─ Fetch ALL accounts (tenant-scoped)
  │
  ├─ prisma.journalLine.groupBy({
  │     by: ['accountId'],
  │     where: { entry: { companyId, tenantId, date: { lte: asOfEnd } } },
  │     _sum: { debit, credit }
  │   })
  │
  ├─ Classify per account type:
  │     ASSET:     balance = rawBalance
  │     LIABILITY: balance = -rawBalance
  │     EQUITY:    balance = -rawBalance
  │     INCOME:    accumulate for P&L
  │     EXPENSE:   accumulate for P&L
  │
  ├─ Add synthetic equity line:
  │     "Current Period Result" = totalIncome - totalExpenses
  │
  ├─ Sort each section by code ASC
  │
  └─ Return { asOf, assets[], liabilities[], equity[], totals{ ..., diff } }
```

## Comparison: Report Endpoints

| Aspect | OSV (T22) | P&L (T25) | Balance Sheet (T26) |
|--------|-----------|-----------|---------------------|
| Date params | Optional from/to | Required from/to | Required asOf |
| Account types | ALL | INCOME+EXPENSE | ALL (split by type) |
| Grouping | Flat list | income[]/expenses[] | assets[]/liabilities[]/equity[] |
| P&L integration | No | Is the P&L | Synthetic equity line |
| Balance check | No | result field | diff field (A = L + E) |
