// app/(dashboard)/company/[companyId]/CompanyContext.tsx
// ═══════════════════════════════════════════════════
// Company Context — single fetch, shared across all children
// Layout loads company data once → context provides to all
// ═══════════════════════════════════════════════════
//
// Usage in any child component:
//   const company = useCompany();
//   console.log(company.id, company.name, company.status);

'use client';

import { createContext, useContext, ReactNode } from 'react';

// ─── TYPE ────────────────────────────────────────
export type CompanyContextType = {
  id: string;
  name: string;
  status: string;
};

// ─── CONTEXT ─────────────────────────────────────
const CompanyContext = createContext<CompanyContextType | null>(null);

// ─── PROVIDER ────────────────────────────────────
// Wraps children with company data from layout server fetch
export function CompanyProvider({
  value,
  children,
}: {
  value: CompanyContextType;
  children: ReactNode;
}) {
  return (
    <CompanyContext.Provider value={value}>
      {children}
    </CompanyContext.Provider>
  );
}

// ─── HOOK ────────────────────────────────────────
// Type-safe access to company data
// Throws if called outside CompanyProvider (developer error)
export function useCompany(): CompanyContextType {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error(
      'useCompany() must be used within <CompanyProvider>. ' +
      'Ensure the component is rendered inside /company/[companyId]/ layout.'
    );
  }
  return context;
}
