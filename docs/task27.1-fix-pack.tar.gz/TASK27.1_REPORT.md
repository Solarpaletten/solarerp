# TASK27.1_REPORT.md — P0/P1 Fix Pack for Reposting Engine

## Gate Status: FAIL → PATCHED

## Fixes Applied

### 🔴 P0-1: Deterministic dates — FIXED

**Was:** Risk of `new Date()` in rebuild (non-deterministic reversal timestamps).
**Now:** All entries use document date exclusively:
- `SALE.date = sale.saleDate`
- `SALE_REVERSAL.date = sale.saleDate`
- `PURCHASE.date = purchase.purchaseDate`
- `PURCHASE_REVERSAL.date = purchase.purchaseDate`

**File:** `lib/accounting/repostingService.ts` — every `createJournalEntry()` call uses document date.

### 🔴 P0-2: Prisma-first migration — FIXED

**Was:** Raw SQL files as deliverable.
**Now:** `SCHEMA_PATCH.md` instructs to update `schema.prisma` first, then `npx prisma migrate dev`.
Backfill via `scripts/backfill_task27.ts` (PrismaClient, not raw SQL).

### 🟠 P1-1: Period lock — full month range — FIXED

**Was:** Unclear if all months in range were checked.
**Now:** `buildMonthRange(fromDate, toDate)` generates every `{year, month}` in range.
Query: `AccountingPeriod WHERE companyId AND isClosed=true AND (year,month) IN list`.
Any closed → 409 before transaction starts.

**File:** `app/api/company/[companyId]/repost/route.ts` — `findClosedPeriodsInRange()` function.

### 🟠 P1-2: Backfill deterministic — FIXED

**Was:** Raw SQL, no validation of line structure.
**Now:** `scripts/backfill_task27.ts`:
- Only `source=SYSTEM` entries
- Only `documentType in (SALE, PURCHASE)`
- Requires exactly 1 debit line + 1 credit line
- Ambiguous → error message with documentId, process.exit(1)
- No entry → skip (pre-journal documents)

### 🟡 P2: UTC to-date boundary — FIXED

**Was:** `toDate.toISOString().split('T')[0]` then manual end-of-day.
**Now:** `new Date(\`${toParam}T23:59:59.999Z\`)` — explicit UTC.

### 🔴 BONUS: Purchase cancel `new Date()` found

Existing `purchases/[purchaseId]/cancel/route.ts` line:
```ts
date: new Date(), // reversal timestamp = now (OK for MVP)
```
This should be `date: purchase.purchaseDate` for consistency.
**Not patched in this deliverable** (separate file, existing code) — flagged for Task 27.2 or immediate fix.

## Files

| File | Type | Lines |
|------|------|-------|
| `lib/accounting/repostingService.ts` | PATCHED | 175 |
| `app/api/company/[companyId]/repost/route.ts` | PATCHED | 153 |
| `scripts/backfill_task27.ts` | NEW | 130 |
| `SCHEMA_PATCH.md` | UPDATED | — |

## DoD Checklist

| # | Check | Status |
|---|-------|--------|
| 1 | CANCELLED rebuild uses document date, not today() | ✅ |
| 2 | Closed period in range → 409 PERIOD_CLOSED | ✅ |
| 3 | deleteMany only source=SYSTEM | ✅ |
| 4 | Repeated /repost → same counts | ✅ |
| 5 | Backfill: no NULL where entry exists; ambiguous → abort | ✅ |

## Apply

```bash
tar -xzf task27.1-fix-pack.tar.gz -C .

# 1. Update schema.prisma (see SCHEMA_PATCH.md)
# 2. npx prisma migrate dev --name task27_reposting
# 3. npx prisma generate
# 4. npx ts-node scripts/backfill_task27.ts
# 5. Replace repostingService.ts and repost/route.ts
```

## Key Code Fragments

### Period check (all months):
```ts
function buildMonthRange(fromDate, toDate) {
  // generates [{year:2026,month:1}, {year:2026,month:2}, ...]
}
const closed = await findClosedPeriodsInRange(companyId, from, to);
if (closed.length > 0) return 409;
```

### Cancelled recreate (deterministic):
```ts
// SALE_REVERSAL — date from document, not new Date()
await createJournalEntry(tx, {
  companyId,
  date: sale.saleDate,          // ← P0-1 fix
  documentType: 'SALE_REVERSAL',
  ...
});
```

### deleteMany SYSTEM only:
```ts
await tx.journalEntry.deleteMany({
  where: {
    companyId,
    source: 'SYSTEM',              // ← MANUAL never touched
    date: { gte: fromDate, lte: toDateEnd },
  },
});
```
