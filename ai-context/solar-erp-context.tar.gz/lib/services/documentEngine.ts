export const documentEngine = {

  draft(document) {
    // create or update draft document
  },

  post(document) {
    // validate document
    // lock document
    // generate accounting entries
    // create warehouse movements
  },

  cancel(document) {
    // reverse accounting
    // reverse warehouse
  },

  copy(document) {
    // duplicate document
    // reset lifecycle state
  },

  repost(document) {
    // remove previous accounting
    // recalculate FIFO
    // regenerate journal entries
  },

  accounting(document) {
    // call journalService
  },

  warehouse(document) {
    // call stockService
  }

}